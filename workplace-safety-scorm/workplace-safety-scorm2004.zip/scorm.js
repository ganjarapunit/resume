/* Workplace Safety Compliance Training - SCORM 2004 Course Application */

(function() {
  'use strict';

  const COURSE_ID = 'workplace-safety-2026';
  const VERSION = '1.0.0';

  const state = {
    currentSection: 0,
    currentLesson: 0,
    completedLessons: new Set(),
    scores: {},
    quizAttempts: {},
    maxAttempts: 3,
    startTime: Date.now(),
    lessonTimes: {},
    draggedItem: null
  };

  const sections = [
    {
      id: 'intro',
      title: 'Introduction',
      icon: '',
      lessons: [
        {
          id: 'welcome',
          title: 'Welcome',
          type: 'content',
          duration: '2 min',
          content: () => `
            <div class="cover-block">
              <div class="cover-icon"></div>
              <h1>Workplace Safety</h1>
              <p class="cover-subtitle">Compliance Training 2026</p>
              <p style="margin-top: 16px; opacity: 0.9;">Comprehensive safety training covering OSHA fundamentals, hazard identification, PPE, emergency procedures, ergonomics, and incident reporting.</p>
              <div style="margin-top: 24px; padding: 12px; background: rgba(255,255,255,0.15); border-radius: 8px;">
                <strong>Duration:</strong> ~50 minutes<br>
                <strong>Assessment:</strong> 20-question final exam (80% to pass)<br>
                <strong>Certificate:</strong> Upon successful completion
              </div>
            </div>
          `
        },
        {
          id: 'objectives',
          title: 'Learning Objectives',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>What You'll Learn</h2>
            <p>By the end of this course, you will be able to:</p>
            <div class="info-box">
              <div class="info-box-title">Course Objectives</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li>Explain OSHA rights and employer responsibilities</li>
                <li>Identify common workplace hazards (chemical, physical, ergonomic)</li>
                <li>Select and properly use appropriate PPE</li>
                <li>Follow emergency procedures for fire, spills, and medical incidents</li>
                <li>Apply ergonomic principles to workstation setup</li>
                <li>Report workplace incidents and near-misses correctly</li>
              </ul>
            </div>
            <h3>Course Sections</h3>
            <div class="two-column" style="margin-top: 16px;">
              <div class="info-box">
                <strong>Part 1:</strong> OSHA Fundamentals<br>
                <strong>Part 2:</strong> Hazard Identification<br>
                <strong>Part 3:</strong> Personal Protective Equipment
              </div>
              <div class="info-box">
                <strong>Part 4:</strong> Emergency Procedures<br>
                <strong>Part 5:</strong> Ergonomics<br>
                <strong>Part 6:</strong> Incident Reporting
              </div>
            </div>
          `
        }
      ]
    },
    {
      id: 'osha',
      title: 'OSHA Fundamentals',
      icon: '',
      lessons: [
        {
          id: 'osha-overview',
          title: 'What is OSHA?',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>The Occupational Safety and Health Administration</h2>
            <p>OSHA is a federal agency established in 1970 under the Occupational Safety and Health Act. Its mission is to ensure safe and healthful working conditions for all workers.</p>
            <h3>Key Facts About OSHA</h3>
            <div class="info-box">
              <div class="info-box-title">OSHA by the Numbers</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>1970:</strong> OSHA established by Congress</li>
                <li><strong>262:</strong> Federal and state OSHA offices nationwide</li>
                <li><strong>100+ million:</strong> Workers protected by OSHA</li>
                <li><strong>32:</strong> States with their own OSHA-approved plans</li>
                <li><strong>$15,625:</strong> Maximum fine per serious violation (2024)</li>
              </ul>
            </div>
            <h3>OSHA Standards</h3>
            <p>OSHA standards are rules that employers must follow to protect workers. They cover:</p>
            <ul style="padding-left: 20px; margin: 12px 0;">
              <li><strong>General Duty Clause:</strong> Employers must provide a workplace free from recognized hazards</li>
              <li><strong>Industry-Specific Standards:</strong> Construction, maritime, agriculture</li>
              <li><strong>Hazard-Specific Standards:</strong> Chemical exposure, noise, fall protection</li>
            </ul>
          `
        },
        {
          id: 'employer-responsibilities',
          title: 'Employer Responsibilities',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>Your Employer's Obligations</h2>
            <p>Under OSHA, employers have specific legal duties to protect workers:</p>
            <div class="info-box">
              <div class="info-box-title">Employer Must Provide</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li>A workplace free from recognized hazards</li>
                <li>Safety training in a language workers understand</li>
                <li>Proper personal protective equipment (PPE) at no cost</li>
                <li>Access to safety data sheets (SDS) for all chemicals</li>
                <li>Emergency action plans and evacuation procedures</li>
                <li>Regular safety inspections and hazard assessments</li>
              </ul>
            </div>
            <div class="warning-box">
              <div class="warning-title">Serious Violations</div>
              <p>Falls, struck-by incidents, caught-in/between, and electrocution are OSHA's "Fatal Four" — the leading causes of construction worker deaths.</p>
            </div>
            <h3>Recordkeeping Requirements</h3>
            <p>Employers must:</p>
            <ul style="padding-left: 20px; margin: 12px 0;">
              <li>Maintain OSHA 300 injury and illness logs</li>
              <li>Post OSHA 300A summary annually (Feb 1 - Apr 30)</li>
              <li>Report fatalities within 8 hours and hospitalizations within 24 hours</li>
            </ul>
          `
        },
        {
          id: 'worker-rights',
          title: 'Your Rights as a Worker',
          type: 'content',
          duration: '2 min',
          content: () => `
            <h2>You Have the Right To:</h2>
            <div class="info-box">
              <div class="info-box-title">Worker Rights Under OSHA</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Safe Workplace:</strong> Work in an environment free from recognized hazards</li>
                <li><strong>Training:</strong> Receive safety training in a language you understand</li>
                <li><strong>Information:</strong> Access to injury/illness data and chemical SDS</li>
                <li><strong>PPE:</strong> Employer-provided PPE at no cost to you</li>
                <li><strong>Report:</strong> Report hazards without fear of retaliation</li>
                <li><strong>Refuse:</strong> Refuse unsafe work without retaliation</li>
                <li><strong>File Complaint:</strong> File a confidential OSHA complaint</li>
              </ol>
            </div>
            <div class="info-box">
              <div class="info-box-title">Anti-Retaliation Protections</div>
              <p>OSHA prohibits employers from retaliating against workers for exercising their rights. Retaliation includes:</p>
              <ul style="margin: 8px 0; padding-left: 20px;">
                <li>Firing or demoting</li>
                <li>Threatening or intimidating</li>
                <li>Reducing hours or pay</li>
                <li>Transferring to undesirable position</li>
              </ul>
            </div>
          `
        },
        {
          id: 'osha-knowledge-check',
          title: 'Knowledge Check',
          type: 'quiz',
          duration: '2 min',
          questions: [
            {
              question: 'What year was OSHA established?',
              options: ['1960', '1965', '1970', '1975'],
              correct: 2,
              explanation: 'OSHA was established in 1970 under the Occupational Safety and Health Act signed by President Nixon.'
            },
            {
              question: 'Which of the following is NOT an employer responsibility?',
              options: [
                'Provide safety training',
                'Pay for employee PPE',
                'File workers compensation claims',
                'Keep injury records'
              ],
              correct: 2,
              explanation: 'Filing workers compensation claims is typically the employee\'s responsibility, though employers must report workplace injuries.'
            },
            {
              question: 'Can an employer retaliate against a worker for reporting a safety hazard?',
              options: [
                'Yes, if the report was unfounded',
                'No, retaliation is prohibited by OSHA',
                'Only if it affects productivity',
                'Only in at-will employment states'
              ],
              correct: 1,
              explanation: 'OSHA prohibits retaliation against workers for exercising their safety rights, regardless of employment status.'
            }
          ]
        }
      ]
    },
    {
      id: 'hazards',
      title: 'Hazard Identification',
      icon: '',
      lessons: [
        {
          id: 'hazard-overview',
          title: 'Types of Workplace Hazards',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>Recognizing Workplace Hazards</h2>
            <p>A hazard is any source of potential harm. Understanding hazard types is the first step in prevention.</p>
            <h3>Chemical Hazards</h3>
            <div class="info-box">
              <div class="info-box-title">Chemical Hazards</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Corrosives:</strong> Acids, alkalis that burn skin/eyes</li>
                <li><strong>Flammables:</strong> Solvents, gases that ignite easily</li>
                <li><strong>Toxic:</strong> Lead, asbestos, silica dust</li>
                <li><strong>Irritants:</strong> Cleaning agents, solvents</li>
              </ul>
              <p><strong>Protection:</strong> Read SDS, use PPE, ensure ventilation, proper storage</p>
            </div>
            <h3>Physical Hazards</h3>
            <div class="info-box">
              <div class="info-box-title">Physical Hazards</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Noise:</strong> >85 dB sustained (machinery, power tools)</li>
                <li><strong>Vibration:</strong> Hand-arm (tools) or whole-body (vehicles)</li>
                <li><strong>Radiation:</strong> X-rays, UV, radiofrequency</li>
                <li><strong>Temperature:</strong> Extreme heat or cold exposure</li>
              </ul>
              <p><strong>Protection:</strong> PPE, engineering controls, work scheduling</p>
            </div>
          `
        },
        {
          id: 'ergonomic-hazards',
          title: 'Ergonomic Hazards',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>Ergonomic Hazards</h2>
            <p>Conditions that force the body into unnatural positions or repetitive motions.</p>
            <div class="info-box">
              <div class="info-box-title">Common Ergonomic Hazards</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Repetitive Motion:</strong> Typing, assembly line work, scanning</li>
                <li><strong>Awkward Postures:</strong> Bending, reaching overhead, twisting</li>
                <li><strong>Forceful Exertion:</strong> Lifting heavy objects, pushing/pulling</li>
                <li><strong>Contact Stress:</strong> Resting wrists on hard edges</li>
                <li><strong>Prolonged Standing/Sitting:</strong> Without breaks</li>
              </ul>
            </div>
            <h3>Resulting Injuries</h3>
            <ul style="padding-left: 20px; margin: 12px 0;">
              <li>Carpal Tunnel Syndrome</li>
              <li>Tendinitis</li>
              <li>Back injuries (herniated discs)</li>
              <li>Rotator cuff injuries</li>
              <li>Trigger finger</li>
            </ul>
            <div class="warning-box">
              <div class="warning-title">Warning Signs</div>
              <p>Numbness, tingling, pain, swelling, or reduced range of motion may indicate an ergonomic injury. Report these symptoms immediately.</p>
            </div>
          `
        },
        {
          id: 'hazard-sorting',
          title: 'Hazard Classification Activity',
          type: 'drag-drop',
          duration: '3 min',
          items: [
            { id: 'h1', text: 'Benzene exposure', correct: 'chemical' },
            { id: 'h2', text: 'Noise from machinery', correct: 'physical' },
            { id: 'h3', text: 'Repetitive typing', correct: 'ergonomic' },
            { id: 'h4', text: 'Sulfuric acid spill', correct: 'chemical' },
            { id: 'h5', text: 'Falling objects', correct: 'physical' },
            { id: 'h6', text: 'Heavy lifting', correct: 'ergonomic' },
            { id: 'h7', text: 'Welding arc flash', correct: 'physical' },
            { id: 'h8', text: 'Cleaning solvents', correct: 'chemical' },
            { id: 'h9', text: 'Prolonged standing', correct: 'ergonomic' }
          ],
          zones: [
            { id: 'chemical', label: 'Chemical Hazard' },
            { id: 'physical', label: 'Physical Hazard' },
            { id: 'ergonomic', label: 'Ergonomic Hazard' }
          ]
        }
      ]
    },
    {
      id: 'ppe',
      title: 'Personal Protective Equipment',
      icon: '',
      lessons: [
        {
          id: 'ppe-overview',
          title: 'PPE Selection Guide',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>Choosing the Right PPE</h2>
            <p>PPE is the last line of defense. Always prioritize elimination, engineering, and administrative controls first.</p>
            <h3>PPE Hierarchy</h3>
            <div class="info-box">
              <div class="info-box-title">Controls Hierarchy (Most to Least Effective)</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Elimination:</strong> Remove the hazard entirely</li>
                <li><strong>Substitution:</strong> Replace with less hazardous material</li>
                <li><strong>Engineering Controls:</strong> Ventilation, machine guards</li>
                <li><strong>Administrative Controls:</strong> Training, scheduling, signs</li>
                <li><strong>PPE:</strong> Last resort — protect the worker</li>
              </ol>
            </div>
            <h3>PPE by Hazard Type</h3>
            <div class="two-column" style="margin-top: 16px;">
              <div class="info-box">
                <strong>Eye/Face Protection:</strong><br>
                Safety glasses, goggles, face shields, welding helmets
              </div>
              <div class="info-box">
                <strong>Hearing Protection:</strong><br>
                Earplugs (foam, pre-molded), earmuffs, canal caps
              </div>
              <div class="info-box">
                <strong>Hand Protection:</strong><br>
                Leather, chemical-resistant, cut-resistant, heat-resistant gloves
              </div>
              <div class="info-box">
                <strong>Respiratory Protection:</strong><br>
                N95, half-face respirators, full-face, SCBA
              </div>
            </div>
          `
        },
        {
          id: 'ppe-donning',
          title: 'Donning & Doffing PPE',
          type: 'content',
          duration: '2 min',
          content: () => `
            <h2>Proper PPE Sequence</h2>
            <h3>Donning (Putting On)</h3>
            <div class="info-box">
              <div class="info-box-title">Donning Order</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li>Perform hand hygiene</li>
                <li>Put on gown/coveralls</li>
                <li>Put on mask/respirator (ensure seal)</li>
                <li>Put on goggles/face shield</li>
                <li>Put on gloves (over gown cuffs)</li>
              </ol>
            </div>
            <h3>Doffing (Removing)</h3>
            <div class="warning-box">
              <div class="warning-title">Doffing Order (Remove Contaminants Safely)</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li>Remove gloves (turn inside out)</li>
                <li>Perform hand hygiene</li>
                <li>Remove goggles/face shield</li>
                <li>Remove gown (turn inside out)</li>
                <li>Remove mask/respirator</li>
                <li>Perform hand hygiene</li>
              </ol>
              <p><strong>Critical:</strong> Always remove contaminated items by working from most contaminated (outer) to least contaminated (closest to skin).</p>
            </div>
          `
        }
      ]
    },
    {
      id: 'emergency',
      title: 'Emergency Procedures',
      icon: '',
      lessons: [
        {
          id: 'fire-emergency',
          title: 'Fire Emergency',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>Fire Response: R.A.C.E.</h2>
            <div class="info-box">
              <div class="info-box-title">R.A.C.E. Protocol</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li><strong>R - Rescue:</strong> Alert anyone in immediate danger</li>
                <li><strong>A - Alarm:</strong> Activate fire alarm, call 911</li>
                <li><strong>C - Contain:</strong> Close doors to confine fire</li>
                <li><strong>E - Evacuate/Extinguish:</strong> Evacuate or use extinguisher if safe</li>
              </ol>
            </div>
            <h3>Fire Extinguisher Use: P.A.S.S.</h3>
            <div class="info-box">
              <div class="info-box-title">P.A.S.S. Technique</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>P - Pull:</strong> Pull the safety pin</li>
                <li><strong>A - Aim:</strong> Aim at the base of the fire</li>
                <li><strong>S - Squeeze:</strong> Squeeze the handle</li>
                <li><strong>S - Sweep:</strong> Sweep from side to side</li>
              </ul>
            </div>
            <div class="warning-box">
              <div class="warning-title">When NOT to Fight Fire</div>
              <p>Evacuate immediately if: fire is spreading rapidly, smoke is heavy, you're alone, or the extinguisher is empty. Never fight a fire if it blocks your escape route.</p>
            </div>
          `
        },
        {
          id: 'spill-emergency',
          title: 'Chemical Spill Response',
          type: 'content',
          duration: '2 min',
          content: () => `
            <h2>Chemical Spill Procedures</h2>
            <h3>Small Spill (Minor)</h3>
            <div class="info-box">
              <div class="info-box-title">Minor Spill Response</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li>Alert nearby workers</li>
                <li>Don appropriate PPE</li>
                <li>Contain spill with absorbent material</li>
                <li>Clean up using appropriate methods</li>
                <li>Dispose of materials in proper waste container</li>
                <li>Report to supervisor</li>
              </ol>
            </div>
            <h3>Large Spill (Major)</h3>
            <div class="warning-box">
              <div class="warning-title">Major Spill Response</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li>Evacuate the area immediately</li>
                <li>Alert others and activate alarm if needed</li>
                <li>Close doors to contain the spill</li>
                <li>Call emergency response team</li>
                <li>Do NOT attempt to clean up</li>
                <li>Account for all personnel at assembly point</li>
              </ol>
              <p><strong>Rule of thumb:</strong> If you can't identify the material or it's larger than 1 liter, treat it as a major spill.</p>
            </div>
          `
        },
        {
          id: 'emergency-quiz',
          title: 'Emergency Knowledge Check',
          type: 'quiz',
          duration: '2 min',
          questions: [
            {
              question: 'What does R.A.C.E. stand for in fire response?',
              options: [
                'Run, Alert, Call, Exit',
                'Rescue, Alarm, Contain, Evacuate/Extinguish',
                'React, Act, Control, Eliminate',
                'Respond, Alarm, Control, Escape'
              ],
              correct: 1,
              explanation: 'R.A.C.E. = Rescue anyone in danger, Alarm (call 911), Contain (close doors), Evacuate or Extinguish.'
            },
            {
              question: 'What is the first step when encountering a major chemical spill?',
              options: [
                'Attempt to clean it up',
                'Evacuate the area immediately',
                'Identify the chemical',
                'Call the supervisor'
              ],
              correct: 1,
              explanation: 'For major spills, evacuate immediately. Do not attempt cleanup until the area is declared safe.'
            },
            {
              question: 'What does P.A.S.S. stand for when using a fire extinguisher?',
              options: [
                'Pull, Aim, Squeeze, Sweep',
                'Point, Activate, Spray, Stop',
                'Pull, Activate, Spray, Sweep',
                'Point, Aim, Squeeze, Stop'
              ],
              correct: 0,
              explanation: 'P.A.S.S. = Pull the pin, Aim at base, Squeeze handle, Sweep side to side.'
            }
          ]
        }
      ]
    },
    {
      id: 'ergonomics',
      title: 'Ergonomics',
      icon: '',
      lessons: [
        {
          id: 'workstation-setup',
          title: 'Workstation Setup',
          type: 'content',
          duration: '3 min',
          content: () => `
            <h2>Creating an Ergonomic Workstation</h2>
            <h3>Monitor Setup</h3>
            <div class="info-box">
              <div class="info-box-title">Monitor Positioning</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Distance:</strong> Arm's length away (20-26 inches)</li>
                <li><strong>Height:</strong> Top of screen at or slightly below eye level</li>
                <li><strong>Angle:</strong> Tilted back 10-20 degrees</li>
                <li><strong>Position:</strong> Directly in front of you (no twisting)</li>
              </ul>
            </div>
            <h3>Chair Settings</h3>
            <div class="info-box">
              <div class="info-box-title">Chair Adjustment</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Seat height:</strong> Feet flat on floor, thighs parallel to floor</li>
                <li><strong>Backrest:</strong> Support natural curve of lower back</li>
                <li><strong>Armrests:</strong> Allow shoulders to relax, elbows at 90°</li>
                <li><strong>Seat depth:</strong> 2-4 inches between seat edge and back of knees</li>
              </ul>
            </div>
            <h3>Keyboard and Mouse</h3>
            <ul style="padding-left: 20px; margin: 12px 0;">
              <li>Keyboard at elbow height, wrists neutral (not bent)</li>
              <li>Mouse close to keyboard, same height</li>
              <li>Use a wrist rest for resting (not while typing)</li>
              <li>Keep mouse movements from the elbow, not the wrist</li>
            </ul>
          `
        },
        {
          id: 'stretching',
          title: 'Office Stretching Guide',
          type: 'content',
          duration: '2 min',
          content: () => `
            <h2>Microbreak Stretches</h2>
            <p>Perform these every 30-60 minutes for 1-2 minutes each:</p>
            <div class="info-box">
              <div class="info-box-title">Essential Stretches</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Neck Rolls:</strong> Slowly rotate head in circles, 5 each direction</li>
                <li><strong>Shoulder Shrugs:</strong> Raise shoulders to ears, hold 5 sec, release</li>
                <li><strong>Chest Opener:</strong> Clasp hands behind back, straighten arms, lift</li>
                <li><strong>Wrist Flex/Extend:</strong> Extend arm, pull fingers back gently</li>
                <li><strong>Seated Spine Twist:</strong> Rotate torso, hold chair back for leverage</li>
                <li><strong>Standing Forward Fold:</strong> Bend at hips, let arms hang</li>
              </ul>
            </div>
            <div class="info-box">
              <div class="info-box-title">The 20-20-20 Rule</div>
              <p>Every 20 minutes, look at something 20 feet away for 20 seconds. This reduces eye strain and helps maintain focus.</p>
            </div>
          `
        }
      ]
    },
    {
      id: 'reporting',
      title: 'Incident Reporting',
      icon: '',
      lessons: [
        {
          id: 'why-report',
          title: 'Why Report Incidents?',
          type: 'content',
          duration: '2 min',
          content: () => `
            <h2>The Importance of Reporting</h2>
            <p>Reporting isn't about blame — it's about prevention and improvement.</p>
            <div class="info-box">
              <div class="info-box-title">Benefits of Reporting</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li><strong>Prevention:</strong> Identify root causes to prevent recurrence</li>
                <li><strong>Trend Analysis:</strong> Spot patterns across departments/locations</li>
                <li><strong>Legal Compliance:</strong> Meet OSHA and state requirements</li>
                <li><strong>Workers Comp:</strong> Ensure injured workers receive benefits</li>
                <li><strong>Safety Culture:</strong> Demonstrate organizational commitment</li>
                <li><strong>Insurance:</strong> Accurate data may reduce premiums</li>
              </ul>
            </div>
            <div class="warning-box">
              <div class="warning-title">What Must Be Reported</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li>Fatalities (within 8 hours)</li>
                <li>In-patient hospitalizations (within 24 hours)</li>
                <li>Amputations (within 24 hours)</li>
                <li>Loss of an eye (within 24 hours)</li>
                <li>All recordable injuries and illnesses</li>
              </ul>
            </div>
          `
        },
        {
          id: 'how-to-report',
          title: 'How to Report',
          type: 'content',
          duration: '2 min',
          content: () => `
            <h2>Reporting Process</h2>
            <h3>Immediate Actions</h3>
            <div class="info-box">
              <div class="info-box-title">If Someone Is Injured</div>
              <ol style="margin: 12px 0; padding-left: 20px;">
                <li>Call 911 if life-threatening</li>
                <li>Administer first aid if trained</li>
                <li>Do not move injured person unless danger</li>
                <li>Secure the scene</li>
                <li>Notify supervisor immediately</li>
              </ol>
            </div>
            <h3>Documentation</h3>
            <div class="info-box">
              <div class="info-box-title">Complete an Incident Report</div>
              <ul style="margin: 12px 0; padding-left: 20px;">
                <li>Who, what, when, where, how</li>
                <li>Witness names and statements</li>
                <li>Photos of scene and injuries</li>
                <li>Equipment involved and conditions</li>
                <li>PPE being worn at time of incident</li>
              </ul>
            </div>
            <div class="info-box">
              <div class="info-box-title">Near-Miss Reporting</div>
              <p>A near-miss is an event that could have caused injury but didn't. Reporting near-misses is critical — they're warning signs of potential future incidents. Near-miss reporting should be non-punitive.</p>
            </div>
          `
        }
      ]
    },
    {
      id: 'assessment',
      title: 'Final Assessment',
      icon: '',
      lessons: [
        {
          id: 'final-quiz',
          title: 'Final Exam',
          type: 'assessment',
          duration: '10 min',
          passScore: 80,
          questions: [
            {
              question: 'When was OSHA established?',
              options: ['1960', '1965', '1970', '1975'],
              correct: 2,
              explanation: 'OSHA was established in 1970 under the Occupational Safety and Health Act.'
            },
            {
              question: 'Which is the MOST effective hazard control according to the hierarchy of controls?',
              options: ['PPE', 'Engineering controls', 'Elimination', 'Administrative controls'],
              correct: 2,
              explanation: 'Elimination is the most effective because it removes the hazard entirely.'
            },
            {
              question: 'What is the maximum decibel level for prolonged exposure without hearing protection?',
              options: ['75 dB', '80 dB', '85 dB', '90 dB'],
              correct: 2,
              explanation: 'OSHA requires hearing protection for exposure above 85 dB over an 8-hour time-weighted average.'
            },
            {
              question: 'What does the "E" in R.A.C.E. stand for?',
              options: ['Escape', 'Evacuate/Extinguish', 'Emergency', 'Exit'],
              correct: 1,
              explanation: 'R.A.C.E. = Rescue, Alarm, Contain, Evacuate/Extinguish.'
            },
            {
              question: 'What is the FIRST step in the P.A.S.S. fire extinguisher technique?',
              options: ['Aim at the fire', 'Pull the safety pin', 'Squeeze the handle', 'Sweep side to side'],
              correct: 1,
              explanation: 'P.A.S.S. starts with Pull the safety pin.'
            },
            {
              question: 'What should you do immediately when encountering a major chemical spill?',
              options: [
                'Clean it up immediately',
                'Evacuate the area',
                'Take a photo',
                'Wait for it to evaporate'
              ],
              correct: 1,
              explanation: 'Evacuate immediately for major spills. Do not attempt cleanup until area is declared safe.'
            },
            {
              question: 'Which type of hazard includes repetitive typing motions?',
              options: ['Chemical', 'Physical', 'Ergonomic', 'Biological'],
              correct: 2,
              explanation: 'Repetitive motions are ergonomic hazards that can cause musculoskeletal disorders.'
            },
            {
              question: 'What is the correct order for doffing (removing) PPE?',
              options: [
                'Mask first, then gloves',
                'Gloves first, then gown, then mask',
                'Goggles first, then gloves',
                'Any order is fine'
              ],
              correct: 1,
              explanation: 'Doff from most contaminated to least: gloves → hand hygiene → goggles → gown → mask.'
            },
            {
              question: 'Within how many hours must fatalities be reported to OSHA?',
              options: ['4 hours', '8 hours', '24 hours', '48 hours'],
              correct: 1,
              explanation: 'Fatalities must be reported to OSHA within 8 hours.'
            },
            {
              question: 'What is a "near-miss"?',
              options: [
                'A type of injury',
                'An event that could have caused injury but didn\'t',
                'A type of PPE',
                'An OSHA violation'
              ],
              correct: 1,
              explanation: 'A near-miss is a warning sign — an event that could have resulted in injury but didn\'t.'
            },
            {
              question: 'How far should your monitor be from your eyes?',
              options: ['6-10 inches', '12-16 inches', '20-26 inches', '30-36 inches'],
              correct: 2,
              explanation: 'Monitors should be arm\'s length away, approximately 20-26 inches.'
            },
            {
              question: 'What does the "G" in GHS stand for?',
              options: ['General', 'Global', 'Government', 'Generic'],
              correct: 1,
              explanation: 'GHS stands for Globally Harmonized System of Classification and Labelling of Chemicals.'
            },
            {
              question: 'Which employer must be notified of a hospitalized worker within 24 hours?',
              options: [
                'The employee\'s personal doctor',
                'OSHA',
                'The local fire department',
                'The insurance company'
              ],
              correct: 1,
              explanation: 'OSHA must be notified of in-patient hospitalizations within 24 hours.'
            },
            {
              question: 'What is the 20-20-20 rule for eye strain?',
              options: [
                'Every 20 min, look 20 ft away for 20 sec',
                'Every 20 sec, blink 20 times',
                'Every 20 min, close eyes for 20 sec',
                'Every 20 ft, look up for 20 sec'
              ],
              correct: 0,
              explanation: 'The 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds.'
            },
            {
              question: 'Which of these is NOT a type of PPE?',
              options: ['Safety glasses', 'Earplugs', 'Work instructions', 'Gloves'],
              correct: 2,
              explanation: 'Work instructions are administrative controls, not PPE. PPE protects the body directly.'
            },
            {
              question: 'What is the hierarchy of controls\' least effective method?',
              options: ['Elimination', 'Engineering controls', 'PPE', 'Substitution'],
              correct: 2,
              explanation: 'PPE is the least effective control because it relies on human behavior and can fail.'
            },
            {
              question: 'When should ergonomic microbreak stretches be performed?',
              options: [
                'Only when in pain',
                'Every 30-60 minutes',
                'Once a day',
                'Only on Fridays'
              ],
              correct: 1,
              explanation: 'Microbreak stretches should be performed every 30-60 minutes to prevent musculoskeletal strain.'
            },
            {
              question: 'What is the maximum OSHA fine per serious violation (2024)?',
              options: ['$5,000', '$10,000', '$15,625', '$25,000'],
              correct: 2,
              explanation: 'The maximum OSHA fine per serious violation is $15,625 (as of 2024).'
            },
            {
              question: 'Which action should be taken FIRST when someone is injured?',
              options: [
                'Fill out paperwork',
                'Call 911 if life-threatening',
                'Move the person to safety',
                'Take photos'
              ],
              correct: 1,
              explanation: 'Always call 911 first for life-threatening injuries. Safety of the injured person is the top priority.'
            },
            {
              question: 'What should near-miss reporting be?',
              options: [
                'Punitive to prevent recurrence',
                'Non-punitive to encourage reporting',
                'Optional for workers',
                'Only for supervisors'
              ],
              correct: 1,
              explanation: 'Near-miss reporting should be non-punitive to encourage workers to report without fear of retaliation.'
            }
          ]
        }
      ]
    }
  ];

  function init() {
    SCORMWrapper.init();
    loadSuspendData();
    renderSidebar();
    renderContent();
    updateProgress();
    startTimer();
  }

  function loadSuspendData() {
    const data = SCORMWrapper.getSuspend();
    if (data) {
      try {
        const parsed = JSON.parse(data);
        state.completedLessons = new Set(parsed.completedLessons || []);
        state.scores = parsed.scores || {};
        state.currentSection = parsed.currentSection || 0;
        state.currentLesson = parsed.currentLesson || 0;
        state.quizAttempts = parsed.quizAttempts || {};
      } catch(e) {}
    }
  }

  function saveSuspendData() {
    const data = {
      completedLessons: Array.from(state.completedLessons),
      scores: state.scores,
      currentSection: state.currentSection,
      currentLesson: state.currentLesson,
      quizAttempts: state.quizAttempts
    };
    SCORMWrapper.suspend(JSON.stringify(data));
  }

  function startTimer() {
    setInterval(() => {
      const elapsed = Math.floor((Date.now() - state.startTime) / 60000);
      const timer = document.getElementById('session-timer');
      if (timer) timer.textContent = `Session: ${elapsed} min`;
    }, 60000);
  }

  /* ─── Section Locking Helpers ─── */
  const ASSESSMENT_GATES = [
    { sectionIndex: 1, lessonIndex: 3, lessonId: 'osha-knowledge-check' },
    { sectionIndex: 4, lessonIndex: 2, lessonId: 'emergency-quiz' }
  ];

  function isAssessmentPassed(sectionIndex, lessonIndex) {
    const lesson = sections[sectionIndex]?.lessons[lessonIndex];
    if (!lesson) return false;
    return state.scores[lesson.id]?.passed === true;
  }

  function isSectionLocked(si) {
    if (si <= 1) return false;
    if (si >= 2 && si <= 4) return !isAssessmentPassed(1, 3);
    if (si >= 5 && si <= 7) return !isAssessmentPassed(1, 3) || !isAssessmentPassed(4, 2);
    return false;
  }

  function isLessonAccessible(si, li) {
    if (isSectionLocked(si)) return false;
    for (const gate of ASSESSMENT_GATES) {
      if (si === gate.sectionIndex && li > gate.lessonIndex) {
        if (!isAssessmentPassed(gate.sectionIndex, gate.lessonIndex)) return false;
      }
    }
    return true;
  }

  function isCourseComplete() {
    return isAssessmentPassed(1, 3) && isAssessmentPassed(4, 2) && isAssessmentPassed(7, 0);
  }

  /* Check course completion by reading fresh data from localStorage,
     bypassing the IIFE closure state which may be stale due to
     the SCORM wrapper's beforeunload handler overwriting saves. */
  function isCourseCompleteFresh() {
    try {
      const raw = localStorage.getItem('scorm_wrapper_data');
      if (!raw) return false;
      const wd = JSON.parse(raw);
      const suspendData = wd['cmi.suspend_data'];
      if (!suspendData) return false;
      const parsed = JSON.parse(suspendData);
      const scores = (typeof parsed === 'string') ? JSON.parse(parsed).scores : parsed.scores;
      if (!scores) return false;
      return scores['osha-knowledge-check']?.passed === true
          && scores['emergency-quiz']?.passed === true
          && scores['final-quiz']?.passed === true;
    } catch (e) {
      return false;
    }
  }

  function showCertificate() {
    const overlay = document.createElement('div');
    overlay.className = 'certificate-overlay';
    overlay.id = 'certificate-overlay';
    overlay.innerHTML = `
      <div class="certificate-modal">
        <div id="certificate-content" style="padding: 40px; font-family: 'Georgia', serif; border: 3px solid #1a237e; border-radius: 8px; background: linear-gradient(135deg, #fafbff 0%, #f0f3ff 100%);">
          <div style="text-align: center; margin-bottom: 8px;">
            <div style="font-size: 13px; letter-spacing: 3px; text-transform: uppercase; color: #1a237e; font-weight: bold;">Workplace Safety Compliance Training</div>
          </div>
          <div style="text-align: center; margin: 20px 0 10px;">
            <div style="width: 60px; height: 2px; background: #1a237e; margin: 0 auto 20px;"></div>
            <div style="font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: #888; margin-bottom: 8px;">Certificate of Completion</div>
            <div style="font-size: 14px; color: #666;">This is to certify that</div>
          </div>
          <div style="text-align: center; margin: 15px 0;">
            <div style="font-size: 28px; font-weight: bold; color: #1a237e; border-bottom: 2px solid #1a237e; padding-bottom: 6px; display: inline-block; min-width: 300px;">${state.learnerName || 'Workplace Safety Learner'}</div>
          </div>
          <div style="text-align: center; margin: 15px 0; font-size: 14px; color: #555; line-height: 1.8;">
            has successfully completed all requirements of the<br>
            <strong style="color: #1a237e;">Workplace Safety Compliance Training Program</strong><br>
            <span style="font-size: 12px; color: #888;">including OSHA Fundamentals, Hazard Identification, PPE,<br>Emergency Procedures, Ergonomics, and Incident Reporting</span>
          </div>
          <div style="text-align: center; margin: 10px 0;">
            <div style="font-size: 12px; color: #888;">Date: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
          </div>
          <div style="display: flex; justify-content: space-between; margin-top: 30px; padding: 0 20px;">
            <div style="text-align: center; width: 180px;">
              <div style="border-top: 1px solid #333; padding-top: 6px; font-size: 12px; color: #555;">${state.learnerName || 'Program Director'}</div>
              <div style="font-size: 10px; color: #888; margin-top: 2px;">Program Director</div>
            </div>
            <div style="text-align: center; width: 180px;">
              <div style="border-top: 1px solid #333; padding-top: 6px; font-size: 12px; color: #555;">Workplace Safety Institute</div>
              <div style="font-size: 10px; color: #888; margin-top: 2px;">Issuing Organization</div>
            </div>
          </div>
        </div>
        <div class="certificate-actions">
          <button class="btn-print" onclick="window.print()">Print Certificate</button>
          <button class="btn-close" onclick="document.getElementById('certificate-overlay').remove()">Close</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
  }

  window.showCertificate = showCertificate;

  function renderSidebar() {
    const sidebar = document.getElementById('sidebar');
    const nav = document.getElementById('nav-sections');
    nav.innerHTML = '';

    sections.forEach((section, si) => {
      const locked = isSectionLocked(si);
      const sectionEl = document.createElement('div');
      sectionEl.className = 'nav-section' + (si === state.currentSection ? ' active' : '');

      const header = document.createElement('div');
      header.className = 'nav-section-header';
      header.innerHTML = `<span>${locked ? '🔒 ' : ''}${section.title}</span><span class="nav-chevron">▶</span>`;
      header.onclick = () => {
        sectionEl.classList.toggle('collapsed');
        header.querySelector('.nav-chevron').textContent =
          sectionEl.classList.contains('collapsed') ? '▶' : '▼';
      };
      sectionEl.appendChild(header);

      const lessons = document.createElement('div');
      lessons.className = 'nav-lessons';

      section.lessons.forEach((lesson, li) => {
        const accessible = isLessonAccessible(si, li);
        const lessonEl = document.createElement('div');
        lessonEl.className = 'nav-lesson' +
          (si === state.currentSection && li === state.currentLesson ? ' active' : '') +
          (state.completedLessons.has(`${si}-${li}`) ? ' completed' : '') +
          (!accessible ? ' locked' : '');

        const icon = state.completedLessons.has(`${si}-${li}`) ? '✓' : (!accessible ? '<span class="lock-indicator">🔒</span>' : '');
        lessonEl.innerHTML = `<span>${icon}</span><span>${lesson.title}</span>`;
        if (accessible) lessonEl.onclick = () => navigateTo(si, li);
        lessons.appendChild(lessonEl);
      });

      sectionEl.appendChild(lessons);
      nav.appendChild(sectionEl);
    });

    const progress = document.getElementById('sidebar-progress');
    const total = sections.reduce((acc, s) => acc + s.lessons.length, 0);
    const completed = state.completedLessons.size;
    const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
    progress.innerHTML = `<div class="progress-bar" style="height: 6px; background: rgba(255,255,255,0.2); border-radius: 3px; margin-top: 12px;"><div class="progress-fill" style="height: 100%; width: ${pct}%; background: #48BB78; border-radius: 3px;"></div></div><div style="text-align: center; margin-top: 8px; font-size: 12px;">${completed}/${total} lessons (${pct}%)</div>`;

    const certContainer = document.getElementById('sidebar-certificate');
    if (isCourseCompleteFresh()) {
      certContainer.innerHTML = '<button class="sidebar-cert-btn unlocked" onclick="showCertificate()"><span class="cert-icon">🏆</span> View Certificate</button>';
    } else {
      certContainer.innerHTML = '<button class="sidebar-cert-btn locked" disabled><span class="cert-icon">🔒</span> Complete all assessments to unlock</button>';
    }
  }

  function renderContent() {
    const content = document.getElementById('content');
    const section = sections[state.currentSection];
    const lesson = section.lessons[state.currentLesson];

    document.getElementById('breadcrumb').innerHTML =
      `<span class="breadcrumb-item">${section.title}</span><span class="breadcrumb-separator">›</span><span class="breadcrumb-item">${lesson.title}</span>`;

    document.getElementById('lesson-title').textContent = lesson.title;
    document.getElementById('lesson-duration').textContent = lesson.duration;

    // Show locked overlay if section is locked
    if (isSectionLocked(state.currentSection)) {
      let requiredQuizzes = '';
      if (state.currentSection >= 2 && state.currentSection <= 4) {
        requiredQuizzes = '<ul><li>OSHA Fundamentals Knowledge Check (Section 1, Lesson 4)</li></ul>';
      } else if (state.currentSection >= 5) {
        requiredQuizzes = '<ul><li>OSHA Fundamentals Knowledge Check (Section 1, Lesson 4)</li><li>Emergency Procedures Quiz (Section 5, Lesson 3)</li></ul>';
      }
      content.innerHTML = `
        <div class="section-locked-overlay">
          <div class="lock-icon">🔒</div>
          <h2>Section Locked</h2>
          <p>Complete the required assessments in previous sections to unlock this content.</p>
          <div class="required-quizzes">
            <strong>Required assessments:</strong>
            ${requiredQuizzes}
          </div>
        </div>`;
      document.getElementById('btn-prev').disabled = true;
      document.getElementById('btn-next').disabled = true;
      return;
    }

    let html = '';
    if (lesson.type === 'quiz' || lesson.type === 'assessment') {
      html = renderQuiz(lesson);
    } else if (lesson.type === 'drag-drop') {
      html = renderDragDrop(lesson);
    } else {
      html = lesson.content();
    }

    content.innerHTML = html;

    if (lesson.type === 'quiz' || lesson.type === 'assessment') {
      initQuiz(lesson);
    } else if (lesson.type === 'drag-drop') {
      initDragDrop(lesson);
    }

    content.scrollTop = 0;

    document.getElementById('btn-prev').disabled = (state.currentSection === 0 && state.currentLesson === 0);
    document.getElementById('btn-next').disabled = (state.currentSection === sections.length - 1 && state.currentLesson === section.lessons.length - 1);

    const key = `${state.currentSection}-${state.currentLesson}`;
    if (!state.completedLessons.has(key) && lesson.type !== 'quiz' && lesson.type !== 'assessment' && lesson.type !== 'drag-drop') {
      setTimeout(() => {
        state.completedLessons.add(key);
        saveSuspendData();
        renderSidebar();
        updateProgress();
      }, 3000);
    }
  }

  function renderQuiz(lesson) {
    let html = '';
    if (lesson.type === 'assessment') {
      html += `<div class="info-box"><div class="info-box-title">Final Assessment</div><p>This assessment contains ${lesson.questions.length} questions. You need ${lesson.passScore}% to pass. You have ${Math.max(0, state.maxAttempts - (state.quizAttempts[lesson.id] || 0))} attempt(s) remaining.</p></div>`;
    }
    html += '<div id="quiz-container">';
    lesson.questions.forEach((q, i) => {
      html += `<div class="quiz-question" id="q${i}"><div class="quiz-question-text">${i + 1}. ${q.question}</div><div class="quiz-options">`;
      q.options.forEach((opt, j) => {
        html += `<div class="quiz-option" data-question="${i}" data-option="${j}" onclick="QuizEngine.selectOption(${i}, ${j})"><span class="quiz-option-marker">${String.fromCharCode(65 + j)}</span><span>${opt}</span></div>`;
      });
      html += `<div class="quiz-feedback" id="feedback${i}"></div></div></div>`;
    });
    html += '</div>';
    html += `<div style="text-align: center; margin-top: 24px;"><button class="btn btn-primary" id="btn-submit-quiz" onclick="QuizEngine.submitQuiz()" disabled>Submit Assessment</button></div>`;
    html += '<div id="quiz-results" style="display:none;"></div>';
    return html;
  }

  function renderDragDrop(lesson) {
    let html = `<div class="info-box"><div class="info-box-title">Drag and Drop Activity</div><p>Drag each hazard to its correct category. All items must be correctly placed to complete this activity.</p></div>`;
    html += '<div class="drag-drop-container">';
    html += '<div class="drag-drop-items" id="drag-items">';
    const shuffled = [...lesson.items].sort(() => Math.random() - 0.5);
    shuffled.forEach(item => {
      html += `<div class="drag-item" draggable="true" data-id="${item.id}" data-correct="${item.correct}">${item.text}</div>`;
    });
    html += '</div>';
    html += '<div class="drag-drop-zones">';
    lesson.zones.forEach(zone => {
      html += `<div class="drop-zone" data-zone="${zone.id}"><div class="drop-zone-label">${zone.label}</div></div>`;
    });
    html += '</div></div>';
    html += '<div style="text-align: center; margin-top: 16px;"><button class="btn btn-primary" id="btn-check-sorting" onclick="DragDropEngine.checkAnswers()">Check Answers</button></div>';
    html += '<div id="sorting-results" style="margin-top: 16px;"></div>';
    return html;
  }

  function initQuiz(lesson) {
    window.QuizEngine = {
      answers: new Map(),
      submitted: false,

      selectOption(qi, oi) {
        if (this.submitted) return;
        this.answers.set(qi, oi);
        const options = document.querySelectorAll(`[data-question="${qi}"]`);
        options.forEach(o => o.classList.remove('selected'));
        options[oi].classList.add('selected');
        if (this.answers.size === lesson.questions.length) {
          document.getElementById('btn-submit-quiz').disabled = false;
        }
      },

      submitQuiz() {
        if (this.submitted) return;
        if (this.answers.size < lesson.questions.length) return;

        if (lesson.type === 'assessment') {
          state.quizAttempts[lesson.id] = (state.quizAttempts[lesson.id] || 0) + 1;
          saveSuspendData();
        }

        let correct = 0;
        lesson.questions.forEach((q, i) => {
          const userAnswer = this.answers.get(i);
          const options = document.querySelectorAll(`[data-question="${i}"]`);
          options.forEach(o => { o.classList.remove('selected'); o.style.pointerEvents = 'none'; });

          if (userAnswer === q.correct) {
            options[userAnswer].classList.add('correct');
            correct++;
          } else {
            if (userAnswer !== undefined) options[userAnswer].classList.add('incorrect');
            options[q.correct].classList.add('correct');
          }

          document.getElementById(`feedback${i}`).innerHTML =
            `<div class="quiz-feedback-text">${userAnswer === q.correct ? '✓ Correct!' : '✗ Incorrect'} ${q.explanation}</div>`;
        });

        this.submitted = true;
        document.getElementById('btn-submit-quiz').style.display = 'none';

        const pct = Math.round((correct / lesson.questions.length) * 100);
        const passed = pct >= (lesson.passScore || 70);

        state.scores[lesson.id] = { score: pct, passed, correct, total: lesson.questions.length, date: new Date().toISOString() };
        SCORMWrapper.setScore(pct);
        SCORMWrapper.setInteraction(lesson.id, 'scored', pct, lesson.questions.length);

        if (lesson.type === 'assessment') {
          SCORMWrapper.setSuccess(passed);
          SCORMWrapper.setCompletion(true);
        }

        state.completedLessons.add(`${state.currentSection}-${state.currentLesson}`);
        saveSuspendData();
        renderSidebar();
        updateProgress();

        let resultHtml = `<div class="quiz-results-box ${passed ? 'quiz-pass' : 'quiz-fail'}">`;
        resultHtml += `<h3>${passed ? 'Congratulations! You Passed!' : 'Not Quite'}</h3>`;
        resultHtml += `<p>Score: <strong>${correct}/${lesson.questions.length}</strong> (${pct}%)</p>`;
        if (lesson.passScore) resultHtml += `<p>Required: ${lesson.passScore}%</p>`;
        if (lesson.type === 'assessment' && !passed) {
          const remaining = Math.max(0, state.maxAttempts - (state.quizAttempts[lesson.id] || 0));
          if (remaining > 0) {
            resultHtml += `<p>Attempts remaining: ${remaining}</p>`;
            resultHtml += `<button class="btn btn-primary" onclick="location.reload()">Retry Assessment</button>`;
          } else {
            resultHtml += `<p>No attempts remaining. Please contact your administrator.</p>`;
          }
        }
        if (passed && isCourseComplete()) {
          resultHtml += `<div style="margin-top: 16px; padding: 16px; background: #e8f5e9; border-radius: 8px; border: 1px solid #4caf50;">
            <p style="margin: 0 0 12px; font-weight: 600; color: #2e7d32;">You have completed all assessments!</p>
            <button class="btn btn-primary" onclick="showCertificate()" style="background: #1a237e;">View Your Certificate</button>
          </div>`;
        }
        resultHtml += '</div>';
        document.getElementById('quiz-results').innerHTML = resultHtml;
        document.getElementById('quiz-results').style.display = 'block';
      }
    };
  }

  function initDragDrop(lesson) {
    const items = document.querySelectorAll('.drag-item');
    const zones = document.querySelectorAll('.drop-zone');

    items.forEach(item => {
      item.addEventListener('dragstart', e => {
        state.draggedItem = item;
        item.style.opacity = '0.4';
        e.dataTransfer.effectAllowed = 'move';
      });
      item.addEventListener('dragend', () => {
        item.style.opacity = '1';
        state.draggedItem = null;
      });
    });

    zones.forEach(zone => {
      zone.addEventListener('dragover', e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        zone.classList.add('drag-over');
      });
      zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
      zone.addEventListener('drop', e => {
        e.preventDefault();
        zone.classList.remove('drag-over');
        if (state.draggedItem) {
          zone.appendChild(state.draggedItem);
          state.draggedItem = null;
        }
      });
    });
  }

  window.DragDropEngine = {
    checkAnswers() {
      let correct = 0;
      const total = document.querySelectorAll('.drag-item').length;
      document.querySelectorAll('.drop-zone').forEach(zone => {
        const zoneId = zone.dataset.zone;
        zone.querySelectorAll('.drag-item').forEach(item => {
          if (item.dataset.correct === zoneId) {
            item.classList.add('correct');
            correct++;
          } else {
            item.classList.add('incorrect');
          }
        });
      });

      const pct = Math.round((correct / total) * 100);
      const passed = pct >= 70;
      state.scores['hazard-sorting'] = { score: pct, passed };
      state.completedLessons.add(`${state.currentSection}-${state.currentLesson}`);
      saveSuspendData();
      renderSidebar();
      updateProgress();

      document.getElementById('sorting-results').innerHTML =
        `<div class="info-box"><div class="info-box-title">${passed ? 'Activity Complete!' : 'Try Again'}</div><p>Score: ${correct}/${total} (${pct}%)</p></div>`;
    }
  };

  function navigateTo(si, li) {
    if (!isLessonAccessible(si, li)) {
      // Show locked overlay for the section the user tried to access
      state.currentSection = si;
      state.currentLesson = li;
      saveSuspendData();
      renderSidebar();
      renderContent();
      return;
    }
    state.currentSection = si;
    state.currentLesson = li;
    saveSuspendData();
    renderSidebar();
    renderContent();
  }

  window.navigateTo = navigateTo;

  window.navigateNext = function() {
    const section = sections[state.currentSection];
    if (state.currentLesson < section.lessons.length - 1) {
      const nextLi = state.currentLesson + 1;
      if (isLessonAccessible(state.currentSection, nextLi)) {
        state.currentLesson = nextLi;
      } else {
        // Quiz within section is locked - stop here
        return;
      }
    } else if (state.currentSection < sections.length - 1) {
      const nextSi = state.currentSection + 1;
      if (isLessonAccessible(nextSi, 0)) {
        state.currentSection = nextSi;
        state.currentLesson = 0;
      } else {
        // Next section is locked
        return;
      }
    }
    saveSuspendData();
    renderSidebar();
    renderContent();
  };

  window.navigatePrev = function() {
    if (state.currentLesson > 0) {
      state.currentLesson--;
    } else if (state.currentSection > 0) {
      state.currentSection--;
      state.currentLesson = sections[state.currentSection].lessons.length - 1;
    }
    saveSuspendData();
    renderSidebar();
    renderContent();
  };

  function updateProgress() {
    const total = sections.reduce((acc, s) => acc + s.lessons.length, 0);
    const completed = state.completedLessons.size;
    const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
    // Update bottom bar
    const prog = document.getElementById('lesson-progress');
    if (prog) prog.textContent = `${completed}/${total} lessons completed (${pct}%)`;
    // Update sidebar progress text and bar
    const progressText = document.getElementById('progress-text');
    if (progressText) progressText.textContent = `${pct}% Complete`;
    const progressFill = document.getElementById('progress-fill');
    if (progressFill) progressFill.style.width = `${pct}%`;
    SCORMWrapper.setCompletion(pct >= 100);
  }

  // Sidebar toggle
  window.toggleSidebar = function() {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('sidebar-toggle');
    sidebar.classList.toggle('collapsed');
    toggle.textContent = sidebar.classList.contains('collapsed') ? '☰' : '✕';
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
